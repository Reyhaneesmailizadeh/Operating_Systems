import socket
import sys

import pygame
import threading

WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
LINE_COLOR = (0, 0, 0)

# Initialize pygame
pygame.init()

# Set the dimensions of the screen
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 800
SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Tic Tac Toe")

# Font settings
FONT_SIZE = 40
FONT = pygame.font.Font(None, FONT_SIZE)





class TicTacToeClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.symbol = None
        self.sign = ""
        self.lock = threading.Lock()
        self.data = ""
        self.board_size = 5
        self.screen_height = 800
        self.screen_width = 800

    def receive_data(self):
        self.client_socket.connect((self.host, self.port))
        self.symbol = self.client_socket.recv(1024).decode()
        while "sign" not in self.symbol:
            print(self.symbol)
            self.symbol = self.client_socket.recv(1024).decode()
        if "X" in self.symbol:
            self.sign = "X"
        elif "O" in self.symbol:
            self.sign = "O"
        while True:
            if "|" in self.symbol:
                self.data = self.symbol
                self.symbol = ""
            else:
                self.data = self.client_socket.recv(1024).decode()
            if self.data:
                print(self.data)
                if "|" in self.data:
                    self.draw(self.data)
                elif "Victory" in self.data or "Defeat" in self.data or "The End" in self.data:
                    break

    def draw(self, board_str):
        with self.lock:
            SCREEN.fill(WHITE)
            # Draw horizontal lines
            for i in range(1, self.board_size):
                pygame.draw.line(SCREEN, LINE_COLOR, (0, i * (self.screen_height // self.board_size)),
                                 (self.screen_width, i * (self.screen_height // self.board_size)), 2)
            # Draw vertical lines
            for j in range(1, self.board_size):
                pygame.draw.line(SCREEN, LINE_COLOR, (j * (self.screen_width // self.board_size), 0),
                                 (j * (self.screen_width // self.board_size), self.screen_height), 2)

            lines = board_str.split('\n')
            for i, line in enumerate(lines):
                for j, cell in enumerate(line.split('|')):
                    x = j * (self.screen_width // self.board_size)
                    y = i * (self.screen_height // self.board_size)
                    if cell == 'X':
                        text = pygame.font.SysFont(None, 60).render('X', True, RED)
                    elif cell == 'O':
                        text = pygame.font.SysFont(None, 60).render('O', True, BLUE)
                    else:
                        text = pygame.font.SysFont(None, 60).render('', True, (0, 0, 0))
                    text_rect = text.get_rect(center=(x + (self.screen_width // (self.board_size * 2)),
                                                       y + (self.screen_height // (self.board_size * 2))))
                    SCREEN.blit(text, text_rect)
            pygame.display.flip()

    def get_selected_cell(self, mouse_pos):
        cell_width = self.screen_width // self.board_size
        cell_height = (self.screen_height // self.board_size)
        col = int(mouse_pos[0] // cell_width)
        row = int(mouse_pos[1] // cell_height)
        return row, col

    def run(self):
        threading.Thread(target=self.receive_data, daemon=True).start()
        self.play()

    def play(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and "turn" in self.data:
                    mouse_pos = pygame.mouse.get_pos()
                    row, col = self.get_selected_cell(mouse_pos)
                    print(f"Selected cell: {row}, {col}")
                    self.client_socket.send(f"{row},{col},{self.sign}".encode())


if __name__ == "__main__":
    client = TicTacToeClient('localhost', 5556)
    client.run()
