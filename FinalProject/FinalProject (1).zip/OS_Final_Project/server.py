import socket
import sys
import threading
import random


class TicTacToeServer:
    def __init__(self, host, port):
        self.semaphore = threading.Lock()
        self.end = False
        self.first_player_symbol = "None"
        self.second_player_symbol = "None"
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.board_size = 5
        self.board = [[' ' for _ in range(self.board_size)] for _ in range(self.board_size)]
        self.connections = []
        self.turn = 0

    def start(self):
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(2)
        print("Server started, waiting for connections...")
        while len(self.connections) < 2:
            conn, addr = self.server_socket.accept()
            print(f"Connected to {addr}")
            self.connections.append(conn)
            self.send_message_to_client(0, "wait for another player to join. game will start soon")
        self.send_message_to_client(0, "we found you an enemy! lets start the game\n")
        self.send_message_to_client(1, "There is an opponent waiting for you! lets start the game")
        sign = random.random()
        if sign >= 0.5:
            self.send_message_to_client(0, "\nyour sign is X")
            self.send_message_to_client(1, "\nyour sign is O")
            self.first_player_symbol = "X"
            self.second_player_symbol = "O"

        else:
            self.send_message_to_client(1, "\nyour sign is X")
            self.send_message_to_client(0, "\nyour sign is O")
            self.first_player_symbol = 'O'
            self.second_player_symbol = 'X'
        self.send_message_to_client(0, "\nGame has been started")
        self.send_message_to_client(1, "\nGame has been started")
        threading.Thread(target=self.handle_client, args=(self.connections[0],)).start()
        threading.Thread(target=self.handle_client, args=(self.connections[1],)).start()

    def handle_client(self, conn):
        yet = False
        self.send_board_to_clients()
        while True:
            print(conn)
            if not self.end:
                if not yet:
                    self.semaphore.acquire()
                if conn == self.connections[0]:
                    turn = 0
                else:
                    turn = 1
                if self.end:
                    break
                self.send_message_to_client(turn, "\nit is your turn. Enter row and column of your move: ")

                data = conn.recv(1024).decode()
                row, col, sign = data.split(',')
                row, col = int(row), int(col)
                if self.is_valid_move(row, col):
                    self.board[row][col] = sign
                    self.send_board_to_clients()
                    output = self.check_win()
                    if output == 1:
                        if self.first_player_symbol == "X":
                            self.send_message_to_client(0, "\nVictory!!!!!!!!!!!")
                            self.send_message_to_client(1, "\nDefeat!!!!!!!!!!!")
                        if self.first_player_symbol == "O":
                            self.send_message_to_client(1, "\nVictory!!!!!!!!!!!")
                            self.send_message_to_client(0, "\nDefeat!!!!!!!!!!!")
                        self.end = True
                    elif output == 0:
                        if self.first_player_symbol == "X":
                            self.send_message_to_client(1, "\nVictory!!!!!!!!!!!")
                            self.send_message_to_client(0, "\nDefeat!!!!!!!!!!!")
                        if self.first_player_symbol == "O":
                            self.send_message_to_client(0, "\nVictory!!!!!!!!!!!")
                            self.send_message_to_client(1, "\nDefeat!!!!!!!!!!!")
                        self.end = True
                    yet = False
                else:
                    conn.send("\nInvalid move. Try again.".encode())
                    yet = True
                if self.all_full():
                    self.end = True
                    self.send_message_to_client(0, "\nThe End")
                    self.send_message_to_client(1, "\nThe End")
                if not yet:
                    self.semaphore.release()
            if self.end:
                sys.exit()

    def is_valid_move(self, row, col):
        return 0 <= row < self.board_size and 0 <= col < self.board_size and self.board[row][col] == ' '

    def send_board_to_clients(self):
        board_str = '\n'.join(['|'.join(row) for row in self.board])
        for conn in self.connections:
            conn.send(board_str.encode())

    def send_message_to_client(self, client_index, message):
        self.connections[client_index].send(message.encode())

    def check_win(self):
        output = 2
        if self.board_size == 3:
            # Check rows
            for row in self.board:
                if all(cell == 'X' for cell in row):
                    return 1
                if all(cell == 'O' for cell in row):
                    return 0

            # Check columns
            for col in range(self.board_size):
                column = [self.board[row][col] for row in range(self.board_size)]
                if all(cell == 'X' for cell in column):
                    return 1
                if all(cell == 'O' for cell in column):
                    return 0

            # Check diagonals
            if all(self.board[i][i] == 'X' for i in range(self.board_size)):
                return 1
            if all(self.board[i][i] == 'O' for i in range(self.board_size)):
                return 0
            if all(self.board[i][self.board_size - 1 - i] == 'X' for i in range(self.board_size)):
                return 1
            if all(self.board[i][self.board_size - 1 - i] == 'O' for i in range(self.board_size)):
                return 0
        else:
            # Check rows
            for row in self.board:
                if any(row[i:i + 4] == ['X'] * 4 for i in range(self.board_size - 3)):
                    return 1
                if any(row[i:i + 4] == ['O'] * 4 for i in range(self.board_size - 3)):
                    return 0

            # Check columns
            for col in range(self.board_size):
                column = [self.board[row][col] for row in range(self.board_size)]
                if any(column[i:i + 4] == ['X'] * 4 for i in range(self.board_size - 3)):
                    return 1
                if any(column[i:i + 4] == ['O'] * 4 for i in range(self.board_size - 3)):
                    return 0

            # Check diagonals
            for i in range(self.board_size - 3):
                for j in range(self.board_size - 3):
                    if all(self.board[i + k][j + k] == 'X' for k in range(4)):
                        return 1
                    if all(self.board[i + k][j + k] == 'O' for k in range(4)):
                        return 0
                    if all(self.board[i + k][j + 3 - k] == 'X' for k in range(4)):
                        return 1
                    if all(self.board[i + k][j + 3 - k] == 'O' for k in range(4)):
                        return 0

        return output

    def all_full(self):
        for row in self.board:
            for cell in row:
                if cell == ' ':
                    return False
        return True


if __name__ == "__main__":
    server = TicTacToeServer('localhost', 5556)
    server.start()

