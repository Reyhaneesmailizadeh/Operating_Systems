import threading
import time

#In Python's threading module, there isn't a direct wait and signal 
# as you would find in lower-level threading constructs like in some 
# other languages (e.g., Java with wait and notify). Instead, Python 
# provides a higher-level threading API that includes Lock, Event, Condition, and Semaphore objects.


n = 5  # Number of processes
binary_semaphore = threading.Lock() # the Lock itself acts as a binary semaphore

def critical_section(process_id):
    # Entry section (before critical section)
    with binary_semaphore:# statement is used to acquire and 
        #release the lock, providing a way to ensure mutual exclusion.
        print(f"Process {process_id} enters the critical section.")

        # Critical Section: Modify the shared resource
        # For simplicity, let's just print the process ID
        print(f"Process {process_id} is in the critical section.")

        # Exit section (after critical section)
        print(f"Process {process_id} exits the critical section.")

def process_function(process_id):
    for _ in range(3):
        # Simulate some non-critical section work
        time.sleep(0.2)

        # Enter the critical section
        critical_section(process_id)

        # Simulate some non-critical section work
        time.sleep(0.2)

if __name__ == "__main__":
    # Create an array of threads to represent the n processes
    processes = []

    # Launch the threads
    for i in range(n):
        process_thread = threading.Thread(target=process_function, args=(i + 1,))
        processes.append(process_thread)
        process_thread.start()

    # Join the threads
    for process_thread in processes:
        process_thread.join()
