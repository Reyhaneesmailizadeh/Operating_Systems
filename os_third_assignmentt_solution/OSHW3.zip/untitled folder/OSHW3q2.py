import threading
import time
import random

class ReadersWriters:
    def __init__(self):
        self.shared_resource = 0
        self.reader_count = 0
        self.resource_lock = threading.Lock()
        self.reader_sem = threading.Semaphore()
        self.global_variable = 0
        self.current_writer = None  # To track the current writer holding the lock

    def read(self, reader_id):
        with self.reader_sem:
            self.reader_count += 1
            if self.reader_count == 1:
                # First reader, acquire the lock
                self.resource_lock.acquire()
                print(f"Reader {reader_id} acquires the lock")

        # Simulating reading from the shared resource
        print(f"Reader {reader_id} reads: {self.shared_resource} (Global Variable: {self.global_variable})")
        time.sleep(random.uniform(0, 1))

        with self.reader_sem:
            self.reader_count -= 1
            if self.reader_count == 0:
                # Last reader, release the lock
                self.resource_lock.release()
                print(f"Reader {reader_id} releases the lock")

    def write(self, writer_id):
        with self.reader_sem:
            # Mark the current writer holding the lock
            self.current_writer = writer_id
            print(f"Writer {writer_id} is waiting for the lock")

        self.resource_lock.acquire()
        print(f"Writer {writer_id} acquires the lock (Current Writer: {self.current_writer})")

        # Simulating writing to the shared resource
        new_value = random.randint(1, 100)
        self.global_variable = new_value
        print(f"Writer {writer_id} writes: {new_value} (Global Variable: {self.global_variable})")
        self.shared_resource = new_value
        time.sleep(random.uniform(0, 1))

        self.resource_lock.release()
        print(f"Writer {writer_id} releases the lock")

def reader_function(reader_id, rw_object):
    for _ in range(3):
        rw_object.read(reader_id)
        time.sleep(random.uniform(0, 1))

def writer_function(writer_id, rw_object):
    for _ in range(3):
        rw_object.write(writer_id)
        time.sleep(random.uniform(0, 1))

if __name__ == "__main__":
    rw_instance = ReadersWriters()

    readers = [threading.Thread(target=reader_function, args=(i, rw_instance)) for i in range(3)]
    writers = [threading.Thread(target=writer_function, args=(i, rw_instance)) for i in range(2)]

    all_threads = readers + writers

    for thread in all_threads:
        thread.start()

    for thread in all_threads:
        thread.join()


