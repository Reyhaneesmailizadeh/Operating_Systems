

import threading
import time
import random
import os

BUFFER_SIZE = 4
TOTAL_ITEMS = 9
NUM_PRODUCERS = 5
NUM_CONSUMERS = 2

buffer = []
mutex = threading.Semaphore(1)
empty = threading.Semaphore(BUFFER_SIZE)
full = threading.Semaphore(0)
items_produced = 0
items_consumed = 0
termination_condition = threading.Condition()

def get_pid():
    return os.getpid()

def producer(producer_id):
    global items_produced
    while items_produced < TOTAL_ITEMS:
        time.sleep(random.uniform(0.1, 0.5))  # Simulate some work
        empty.acquire()
        print(f"Producer {producer_id} (PID: {get_pid()}) is acquiring the mutex.")
        mutex.acquire()
        while len(buffer) == BUFFER_SIZE:
            print(f"Buffer is full. Producer {producer_id} is waiting to push {items_produced + 1}...")
            mutex.release()
            time.sleep(random.uniform(0.1, 0.5))
            if random.choice([True, False]):  # Introduce randomness for producer to try acquiring
                print(f"Producer {producer_id} (PID: {get_pid()}) is attempting to reacquire the mutex.")
                mutex.acquire()
        if items_produced < TOTAL_ITEMS:
            item = random.randint(1, 100)
            print(f"Producer {producer_id} (PID: {get_pid()}), produced {item}. Total items produced: {items_produced + 1}")
            buffer.append(item)
            items_produced += 1
            print(f"Buffer: {buffer}")
        mutex.release()
        print(f"Producer {producer_id} (PID: {get_pid()}) is releasing the mutex.")
        full.release()

    print(f"Producer {producer_id} is done.")

def consumer(consumer_id):
    global items_consumed
    while items_consumed < TOTAL_ITEMS:
        time.sleep(random.uniform(0.1, 0.5))  # Simulate some work
        full.acquire()
        print(f"Consumer {consumer_id} (PID: {get_pid()}) is acquiring the mutex.")
        mutex.acquire()
        # while len(buffer) == 0:
        #     print(f"Buffer is empty. Consumer {consumer_id} is waiting...")
        #     mutex.release()
        #     time.sleep(random.uniform(0.1, 0.5))
        #     if random.choice([True, False]):  # Introduce randomness for consumer to try acquiring
        #         print(f"Consumer {consumer_id} (PID: {get_pid()}) is attempting to reacquire the mutex.")
        #         mutex.acquire()
        if items_consumed < TOTAL_ITEMS and len(buffer) > 0:
            item = buffer.pop(0)
            items_consumed += 1
            print(f"Consumer {consumer_id} (PID: {get_pid()}), consumed {item}. Total items consumed: {items_consumed}")
            print(f"Buffer: {buffer}")
        mutex.release()
        print(f"Consumer {consumer_id} (PID: {get_pid()}) is releasing the mutex.")
        empty.release()

    print(f"Consumer {consumer_id} is done.")

producers = [threading.Thread(target=producer, args=(i,)) for i in range(NUM_PRODUCERS)]
consumers = [threading.Thread(target=consumer, args=(i,)) for i in range(NUM_CONSUMERS)]

for thread in producers + consumers:
    thread.start()

for thread in producers + consumers:
    thread.join()

print("All threads are done.")




